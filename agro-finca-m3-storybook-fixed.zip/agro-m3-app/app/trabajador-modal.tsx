import React from 'react';
import { FormSheet, InputField, ModalHeader } from '@/components';

export default function WorkerModalScreen() {
  return (
    <FormSheet title="Crear / editar trabajador" cta="Guardar perfil">
      <ModalHeader title="Perfil de trabajador" subtitle="Datos mínimos visuales y estado operativo" />
      <InputField label="Nombre" value="Nuevo trabajador" onChangeText={() => {}} />
      <InputField label="Rol" value="Recolector" onChangeText={() => {}} />
      <InputField label="Turno" value="07:00–16:00" onChangeText={() => {}} />
      <InputField label="Contacto" value="+57 ..." onChangeText={() => {}} />
    </FormSheet>
  );
}
