import React from 'react';
import { PremiumSurface, ScreenTemplate, Section } from '@/components';
import { Text } from 'react-native-paper';

export default function HelpScreen() {
  return (
    <ScreenTemplate title="Ayuda" subtitle="Soporte, onboarding y preguntas frecuentes">
      <Section label="Centro de ayuda" />
      <PremiumSurface>
        <Text variant="titleMedium">Cómo registrar una actividad</Text>
        <Text variant="bodyMedium">Usa Acción rápida o el FAB del dashboard para abrir el formulario con secciones de lote, labor, productos y personal.</Text>
      </PremiumSurface>
      <PremiumSurface>
        <Text variant="titleMedium">Cómo revisar sincronización</Text>
        <Text variant="bodyMedium">El SyncStatusChip usa estados tonalizados online, pendiente y error, manteniendo legibilidad AA en claro y oscuro.</Text>
      </PremiumSurface>
    </ScreenTemplate>
  );
}
