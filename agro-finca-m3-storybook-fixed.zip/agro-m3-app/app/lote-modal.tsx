import React from 'react';
import { FormSheet, InputField, ModalHeader } from '@/components';

export default function LotModalScreen() {
  return (
    <FormSheet title="Crear / editar lote" cta="Guardar lote">
      <ModalHeader title="Ficha de lote" subtitle="Alta y edición con props reconectables" />
      <InputField label="Nombre" value="Lote Nuevo" onChangeText={() => {}} />
      <InputField label="Variedad" value="Castillo" onChangeText={() => {}} />
      <InputField label="Área" value="4.5 ha" onChangeText={() => {}} />
      <InputField label="Altitud" value="1.600 msnm" onChangeText={() => {}} />
    </FormSheet>
  );
}
