import React from 'react';
import { useLocalSearchParams } from 'expo-router';
import { Chip, Text } from 'react-native-paper';
import { PremiumSurface, ScreenTemplate, Section } from '@/components';
import { workers } from '@/mocks/data';

export default function WorkerDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const worker = workers.find((item) => item.id === id) ?? workers[0];
  return (
    <ScreenTemplate title={worker.name} subtitle="Detalle de trabajador y desempeño">
      <PremiumSurface>
        <Chip compact>{worker.status}</Chip>
        <Text variant="headlineSmall">{worker.role}</Text>
        <Text variant="bodyMedium">Turno {worker.shift}</Text>
        <Text variant="titleMedium">Rendimiento {worker.performance}%</Text>
      </PremiumSurface>
      <Section label="Historial" />
      <PremiumSurface>
        <Text variant="bodyLarge">Última actividad: Recolección selectiva · 286 kg</Text>
        <Text variant="bodyMedium">Certificaciones visuales: seguridad, manipulación y trazabilidad.</Text>
      </PremiumSurface>
    </ScreenTemplate>
  );
}
