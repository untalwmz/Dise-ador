import React from 'react';
import { Chip, Text } from 'react-native-paper';
import { PremiumSurface, ScreenTemplate, Section } from '@/components';

export default function LogsScreen() {
  const rows = [
    '10:32 · Cola offline drenada correctamente',
    '09:14 · Sincronización de lotes completada',
    '08:03 · Conflicto visual resuelto en movimientos',
  ];
  return (
    <ScreenTemplate title="Logs del sistema" subtitle="Observabilidad legible y auditable">
      <Section label="Eventos recientes" action="Exportar" />
      {rows.map((row, index) => (
        <PremiumSurface key={row}>
          <Text variant="titleMedium">{row}</Text>
          <Chip compact icon={index === 2 ? 'alert-circle-outline' : 'check-circle-outline'}>{index === 2 ? 'Advertencia' : 'OK'}</Chip>
        </PremiumSurface>
      ))}
    </ScreenTemplate>
  );
}
