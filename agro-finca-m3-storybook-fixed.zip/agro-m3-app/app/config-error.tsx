import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { OutlinedButton, PremiumSurface } from '@/components';

export default function ConfigErrorScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 20 }}>
      <PremiumSurface>
        <Text variant="headlineSmall">Error de configuración</Text>
        <Text variant="bodyMedium">Falta una variable del entorno para sincronización. La capa visual muestra errorContainer, diagnóstico y acción recomendada.</Text>
        <OutlinedButton icon="refresh">Reintentar verificación</OutlinedButton>
      </PremiumSurface>
    </View>
  );
}
