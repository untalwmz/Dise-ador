import React from 'react';
import { ScrollView, View } from 'react-native';
import { router } from 'expo-router';
import { Chip, Text } from 'react-native-paper';
import { ActivityCard, AlertCard, HeroScoreCard, InsightCard, KpiBadge, ScreenTemplate, Section, StatCard, WeatherCard } from '@/components';
import { dashboardStats, harvestActivities, heroKpis } from '@/mocks/data';

export default function HomeScreen() {
  return (
    <ScreenTemplate title="Inicio" subtitle="Control premium de la finca cafetalera" actionLabel="Registrar" onAction={() => router.push('/actividad-modal')}>
      <HeroScoreCard title="Índice integral de finca" score={heroKpis.health} caption={heroKpis.sync} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 12 }}>
        {dashboardStats.map((item) => <StatCard key={item.label} label={item.label} value={item.value} trend={item.trend} />)}
      </ScrollView>
      <Section label="Clima y operación" action="Ver agenda" />
      <View style={{ flexDirection: 'row', gap: 12 }}>
        <WeatherCard temperature={heroKpis.climate} subtitle="Ventana óptima para cosecha manual y secado controlado." moisture={heroKpis.moisture} />
      </View>
      <View style={{ flexDirection: 'row', gap: 12, flexWrap: 'wrap' }}>
        <KpiBadge label="Recolectores" value="28" />
        <KpiBadge label="Fermentación" value="6 h" />
        <KpiBadge label="Merma" value="1,8%" />
      </View>
      <InsightCard title="Recomendación" description="Priorizar recolección en La Loma antes de las lluvias de la tarde y mover secado mecánico a las 16:00." footer="IA operacional" />
      <AlertCard title="Atención requerida" description="5 actividades críticas sin cierre digital y 2 compras pendientes de conciliación." />
      <Section label="Actividad de hoy" action="Historial" />
      {harvestActivities.map((item) => <ActivityCard key={item.title} {...item} />)}
      <Chip icon="wifi-sync" onPress={() => router.push('/logs')}>Sincronización offline lista</Chip>
    </ScreenTemplate>
  );
}
