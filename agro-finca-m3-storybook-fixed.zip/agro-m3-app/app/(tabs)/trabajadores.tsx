import React from 'react';
import { router } from 'expo-router';
import { Chip } from 'react-native-paper';
import { PremiumSurface, ScreenTemplate, SearchBarField, Section, StateListItem } from '@/components';
import { workers } from '@/mocks/data';

export default function WorkersScreen() {
  return (
    <ScreenTemplate title="Personal" subtitle="Gestión de cuadrillas, roles y desempeño" actionLabel="Nuevo trabajador" onAction={() => router.push('/trabajador-modal')}>
      <SearchBarField placeholder="Buscar persona, rol o turno" value="" onChangeText={() => {}} />
      <Section label="Equipo activo" action="Turnos" />
      {workers.map((worker) => (
        <PremiumSurface key={worker.id}>
          <StateListItem
            title={worker.name}
            description={`${worker.role} · ${worker.shift}`}
            right={<Chip compact>{worker.status}</Chip>}
            onPress={() => router.push(`/trabajador/${worker.id}`)}
          />
        </PremiumSurface>
      ))}
    </ScreenTemplate>
  );
}
