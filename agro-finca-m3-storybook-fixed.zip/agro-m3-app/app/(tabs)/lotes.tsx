import React from 'react';
import { router } from 'expo-router';
import { Chip, ProgressBar, Text, useTheme } from 'react-native-paper';
import { OutlinedButton, PremiumSurface, ScreenTemplate, SearchBarField, Section, StateListItem } from '@/components';
import { lots } from '@/mocks/data';
import { hectaresLabel, percentageLabel } from '@/utils/format';

export default function LotesScreen() {
  const theme = useTheme();
  return (
    <ScreenTemplate title="Lotes" subtitle="Parcelas, estado fenológico y rendimiento" actionLabel="Nuevo lote" onAction={() => router.push('/lote-modal')}>
      <SearchBarField placeholder="Buscar lote, variedad o labor" value="" onChangeText={() => {}} />
      <Section label="Inventario activo" action="Mapa" />
      {lots.map((lot) => (
        <PremiumSurface key={lot.id}>
          <StateListItem
            title={lot.name}
            description={`${hectaresLabel(lot.hectares)} · ${lot.variety} · ${lot.elevation}`}
            right={<Chip compact>{lot.status}</Chip>}
            onPress={() => router.push(`/lote/${lot.id}`)}
          />
          <ProgressBar progress={lot.progress / 100} color={theme.colors.primary} style={{ height: 8, borderRadius: 999 }} />
          <Text variant="bodySmall" style={{ color: theme.colors.onSurfaceVariant }}>Progreso de ciclo: {percentageLabel(lot.progress)}</Text>
        </PremiumSurface>
      ))}
      <OutlinedButton icon="map-search">Vista satelital y capas</OutlinedButton>
    </ScreenTemplate>
  );
}
