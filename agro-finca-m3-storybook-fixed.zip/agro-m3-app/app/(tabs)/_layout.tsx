import React from 'react';
import { Tabs } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from 'react-native-paper';

export default function TabsLayout() {
  const theme = useTheme();
  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: theme.colors.onSurfaceVariant,
        tabBarStyle: {
          backgroundColor: (theme.colors as any).surfaceContainerLow,
          borderTopColor: theme.colors.outlineVariant,
          height: 72,
          paddingBottom: 10,
          paddingTop: 8,
        },
        tabBarIcon: ({ color, size, focused }) => {
          const map: Record<string, keyof typeof MaterialCommunityIcons.glyphMap> = {
            index: focused ? 'view-dashboard' : 'view-dashboard-outline',
            lotes: focused ? 'map' : 'map-outline',
            accion: focused ? 'lightning-bolt-circle' : 'lightning-bolt-outline',
            finanzas: focused ? 'finance' : 'finance',
            cosecha: focused ? 'coffee' : 'coffee-outline',
            calendario: focused ? 'calendar-month' : 'calendar-month-outline',
            trabajadores: focused ? 'account-group' : 'account-group-outline',
            ajustes: focused ? 'tune-variant' : 'tune',
          };
          const icon = map[route.name] ?? 'leaf';
          return <MaterialCommunityIcons name={icon} size={size} color={color} />;
        },
      })}
    >
      <Tabs.Screen name="index" options={{ title: 'Inicio' }} />
      <Tabs.Screen name="lotes" options={{ title: 'Lotes' }} />
      <Tabs.Screen name="accion" options={{ title: 'Acción' }} />
      <Tabs.Screen name="finanzas" options={{ title: 'Finanzas' }} />
      <Tabs.Screen name="cosecha" options={{ href: null }} />
      <Tabs.Screen name="calendario" options={{ href: null }} />
      <Tabs.Screen name="trabajadores" options={{ href: null }} />
      <Tabs.Screen name="ajustes" options={{ href: null }} />
    </Tabs>
  );
}
