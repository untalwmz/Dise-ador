import React from 'react';
import { PremiumSurface, ScreenTemplate, Section } from '@/components';
import { Text } from 'react-native-paper';

export default function CalendarScreen() {
  const tasks = [
    '06:30 · Reunión de cuadrilla',
    '09:00 · Control de fermentación',
    '11:30 · Compra de insumos',
    '15:00 · Secado y volteo',
  ];

  return (
    <ScreenTemplate title="Calendario" subtitle="Actividades, hitos y ventanas climáticas">
      <Section label="Agenda operativa" action="Semana" />
      {tasks.map((task) => (
        <PremiumSurface key={task}>
          <Text variant="titleMedium">{task}</Text>
          <Text variant="bodyMedium">Con recordatorios, dependencias y color tonal por prioridad.</Text>
        </PremiumSurface>
      ))}
    </ScreenTemplate>
  );
}
