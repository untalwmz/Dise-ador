import React from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { Chip, Text } from 'react-native-paper';
import { FinanceBars, FinanceSegmentedControl, PremiumSurface, ScreenTemplate, Section, SegmentedTrend } from '@/components';
import { financeMovements, financeSummary } from '@/mocks/data';

export default function FinanceScreen() {
  return (
    <ScreenTemplate title="Finanzas" subtitle="PFM agrícola con balance, ingresos y movimientos" actionLabel="Nuevo movimiento" onAction={() => router.push('/movimiento-modal')}>
      <FinanceSegmentedControl />
      <SegmentedTrend
        items={[
          { label: 'Balance', value: financeSummary.balance },
          { label: 'Ingresos', value: financeSummary.income },
          { label: 'Gastos', value: financeSummary.expenses },
        ]}
      />
      <FinanceBars />
      <Section label="Movimientos recientes" action="Exportar" />
      {financeMovements.map((movement) => (
        <PremiumSurface key={movement.id}>
          <Text variant="titleMedium">{movement.title}</Text>
          <Text variant="bodyMedium">{movement.amount}</Text>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Chip compact>{movement.category}</Chip>
            <Text variant="bodySmall">{movement.date}</Text>
          </View>
        </PremiumSurface>
      ))}
    </ScreenTemplate>
  );
}
