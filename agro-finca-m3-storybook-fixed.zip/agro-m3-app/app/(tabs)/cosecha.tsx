import React from 'react';
import { router } from 'expo-router';
import { ActivityCard, FilledButton, ScreenTemplate, Section } from '@/components';
import { harvestActivities } from '@/mocks/data';

export default function HarvestScreen() {
  return (
    <ScreenTemplate title="Cosecha" subtitle="Seguimiento diario de recolección y despacho" actionLabel="Nueva labor" onAction={() => router.push('/actividad-modal')}>
      <Section label="Plan del día" action="Capacidad" />
      {harvestActivities.map((item) => <ActivityCard key={item.title} {...item} />)}
      <FilledButton icon="factory" onPress={() => router.push('/beneficio-modal')}>Pasar a beneficio</FilledButton>
    </ScreenTemplate>
  );
}
