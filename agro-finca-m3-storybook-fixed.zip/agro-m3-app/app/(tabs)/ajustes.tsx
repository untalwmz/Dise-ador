import React from 'react';
import { router } from 'expo-router';
import { OutlinedButton, ScreenTemplate, Section, SettingsSwitch } from '@/components';

export default function SettingsScreen() {
  return (
    <ScreenTemplate title="Ajustes" subtitle="Preferencias, conectividad y accesibilidad">
      <Section label="Experiencia" />
      <SettingsSwitch label="Modo oscuro automático" value />
      <SettingsSwitch label="Texto escalable accesible" value />
      <SettingsSwitch label="Sincronización offline prioritaria" value />
      <OutlinedButton icon="alert-circle-outline" onPress={() => router.push('/config-error')}>Ver error de configuración</OutlinedButton>
    </ScreenTemplate>
  );
}
