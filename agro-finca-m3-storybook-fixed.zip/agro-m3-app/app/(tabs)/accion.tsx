import React from 'react';
import { router } from 'expo-router';
import { View } from 'react-native';
import { SelectableCard, ScreenTemplate, Section } from '@/components';
import { quickActions } from '@/mocks/data';

export default function ActionScreen() {
  return (
    <ScreenTemplate title="Acción rápida" subtitle="Entradas operativas de alta frecuencia" actionLabel="Abrir modal" onAction={() => router.push('/quick-action-modal')}>
      <Section label="Accesos directos" action="Editar" />
      <View style={{ gap: 12 }}>
        {quickActions.map((action, index) => (
          <SelectableCard key={action} title={action} description="Atajo con presets de Material You, captura rápida y confirmación tonal." selected={index === 0} />
        ))}
      </View>
    </ScreenTemplate>
  );
}
