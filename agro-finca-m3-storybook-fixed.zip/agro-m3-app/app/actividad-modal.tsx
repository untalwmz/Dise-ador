import React from 'react';
import { Chip, Text } from 'react-native-paper';
import { FilterChips, FormSheet, InputField, ModalHeader } from '@/components';

export default function ActivityModalScreen() {
  return (
    <FormSheet title="Formulario de actividad" cta="Guardar actividad">
      <ModalHeader title="Actividad agrícola" subtitle="Secciones: Lote, labor, productos y personal" />
      <InputField label="Lote" value="La Loma" onChangeText={() => {}} />
      <InputField label="Labor" value="Recolección selectiva" onChangeText={() => {}} />
      <InputField label="Productos" value="Canastillas, guantes, etiquetas" onChangeText={() => {}} />
      <InputField label="Personal" value="12 trabajadores" onChangeText={() => {}} />
      <FilterChips items={['Cosecha', 'Fertilización', 'Control fitosanitario']} />
      <Chip icon="clock-outline">Duración estimada 2 h</Chip>
      <Text variant="bodySmall">Preparado para reconectar callbacks y validaciones existentes.</Text>
    </FormSheet>
  );
}
