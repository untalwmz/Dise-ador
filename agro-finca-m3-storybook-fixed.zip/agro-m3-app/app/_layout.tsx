import 'react-native-gesture-handler';
import React from 'react';
import { Stack } from 'expo-router';
import { AppThemeProvider } from '@/theme';

export default function RootLayout() {
  return (
    <AppThemeProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="login" />
        <Stack.Screen name="reset-password" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="reportes" />
        <Stack.Screen name="ayuda" />
        <Stack.Screen name="logs" />
        <Stack.Screen name="config-error" />
        <Stack.Screen name="loading" />
        <Stack.Screen name="storybook" options={{ headerShown: false }} />
        <Stack.Screen name="lote/[id]" />
        <Stack.Screen name="trabajador/[id]" />
        <Stack.Screen name="actividad-modal" options={{ presentation: 'modal' }} />
        <Stack.Screen name="beneficio-modal" options={{ presentation: 'modal' }} />
        <Stack.Screen name="movimiento-modal" options={{ presentation: 'modal' }} />
        <Stack.Screen name="lote-modal" options={{ presentation: 'modal' }} />
        <Stack.Screen name="trabajador-modal" options={{ presentation: 'modal' }} />
        <Stack.Screen name="quick-action-modal" options={{ presentation: 'modal' }} />
        <Stack.Screen name="+not-found" />
      </Stack>
    </AppThemeProvider>
  );
}
