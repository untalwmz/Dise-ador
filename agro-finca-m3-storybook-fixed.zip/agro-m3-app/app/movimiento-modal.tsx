import React from 'react';
import { SegmentedButtons } from 'react-native-paper';
import { FormSheet, InputField, ModalHeader } from '@/components';

export default function FinanceMovementModalScreen() {
  return (
    <FormSheet title="Movimiento financiero" cta="Guardar movimiento">
      <ModalHeader title="Ingreso / gasto" subtitle="Modal tonal para caja y compras" />
      <SegmentedButtons value="ingreso" onValueChange={() => {}} buttons={[{ value: 'ingreso', label: 'Ingreso' }, { value: 'gasto', label: 'Gasto' }]} />
      <InputField label="Concepto" value="Venta de pergamino" onChangeText={() => {}} />
      <InputField label="Monto" value="4900" onChangeText={() => {}} />
      <InputField label="Categoría" value="Comercialización" onChangeText={() => {}} />
    </FormSheet>
  );
}
