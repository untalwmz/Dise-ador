import React from 'react';
import { QuickActionModalCard } from '@/components/designKit';

export default function QuickActionModalScreen() {
  return <QuickActionModalCard />;
}
