import React from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { Text, TextInput } from 'react-native-paper';
import { FilledButton, InputField, OutlinedButton, PremiumSurface } from '@/components';

export default function LoginScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 20 }}>
      <PremiumSurface style={{ gap: 18 }}>
        <Text variant="headlineMedium">Bienvenido a Agro Finca</Text>
        <Text variant="bodyMedium">Acceso con superficie elevada, inputs M3 y CTA premium.</Text>
        <InputField label="Correo" value="" onChangeText={() => {}} left={<TextInput.Icon icon="email-outline" />} />
        <InputField label="Contraseña" value="" onChangeText={() => {}} secureTextEntry left={<TextInput.Icon icon="lock-outline" />} />
        <FilledButton onPress={() => router.replace('/(tabs)')}>Entrar</FilledButton>
        <OutlinedButton onPress={() => router.push('/reset-password')}>Restablecer contraseña</OutlinedButton>
      </PremiumSurface>
    </View>
  );
}
