import React from 'react';
import { View } from 'react-native';
import { Chip, SegmentedButtons } from 'react-native-paper';
import { InsightCard, ScreenTemplate, Section } from '@/components';
import { reports } from '@/mocks/data';

export default function ReportsScreen() {
  return (
    <ScreenTemplate title="Reportes" subtitle="Analítica, exportables y tab de beneficio" actionLabel="Generar PDF">
      <SegmentedButtons
        value="operacion"
        onValueChange={() => {}}
        buttons={[
          { value: 'operacion', label: 'Operación' },
          { value: 'beneficio', label: 'Beneficio' },
          { value: 'finanzas', label: 'Finanzas' },
        ]}
      />
      <Section label="Biblioteca de reportes" action="Filtros" />
      <View style={{ gap: 12 }}>
        {reports.map((report) => <InsightCard key={report.title} title={report.title} description={report.description} footer="Exportable" />)}
      </View>
      <Chip icon="file-chart">Diseño pensado para PDF y vista móvil</Chip>
    </ScreenTemplate>
  );
}
