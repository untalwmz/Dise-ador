import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { FilledButton, InputField, PremiumSurface } from '@/components';

export default function ResetPasswordScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 20 }}>
      <PremiumSurface>
        <Text variant="headlineSmall">Restablecer contraseña</Text>
        <Text variant="bodyMedium">Enlace seguro con mensajes de ayuda y estados accesibles.</Text>
        <InputField label="Correo de recuperación" value="" onChangeText={() => {}} />
        <FilledButton icon="email-fast">Enviar enlace</FilledButton>
      </PremiumSurface>
    </View>
  );
}
