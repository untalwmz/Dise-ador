import React from 'react';
import { useLocalSearchParams } from 'expo-router';
import { Chip, ProgressBar, Text, useTheme } from 'react-native-paper';
import { PremiumSurface, ScreenTemplate, Section } from '@/components';
import { lots } from '@/mocks/data';

export default function LoteDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const theme = useTheme();
  const lot = lots.find((item) => item.id === id) ?? lots[0];
  return (
    <ScreenTemplate title={lot.name} subtitle="Detalle de lote, métricas y trazabilidad">
      <PremiumSurface>
        <Chip compact>{lot.status}</Chip>
        <Text variant="headlineSmall">{lot.variety}</Text>
        <Text variant="bodyMedium">{lot.elevation} · {lot.hectares} ha</Text>
        <ProgressBar progress={lot.progress / 100} color={theme.colors.primary} style={{ height: 8, borderRadius: 999 }} />
      </PremiumSurface>
      <Section label="Resumen operativo" />
      <PremiumSurface>
        <Text variant="bodyLarge">Última labor: Fertilización foliar</Text>
        <Text variant="bodyMedium">Próxima recomendación: revisión de sombra y floración en 48 horas.</Text>
      </PremiumSurface>
    </ScreenTemplate>
  );
}
