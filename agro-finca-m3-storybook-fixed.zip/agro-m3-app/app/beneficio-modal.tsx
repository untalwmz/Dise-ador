import React from 'react';
import { Chip } from 'react-native-paper';
import { FormSheet, InputField, ModalHeader } from '@/components';

export default function BenefitModalScreen() {
  return (
    <FormSheet title="Formulario de beneficio" cta="Registrar lote">
      <ModalHeader title="Entrada a beneficio" subtitle="Control de proceso húmedo y secado" />
      <InputField label="Lote origen" value="Quebrada Alta" onChangeText={() => {}} />
      <InputField label="Kg cereza" value="780" onChangeText={() => {}} />
      <InputField label="Fermentación estimada" value="14 h" onChangeText={() => {}} />
      <Chip icon="water-sync">Trazabilidad de lavado y secado</Chip>
    </FormSheet>
  );
}
