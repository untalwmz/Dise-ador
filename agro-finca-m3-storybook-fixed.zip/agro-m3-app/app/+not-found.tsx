import React from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { Text } from 'react-native-paper';
import { FilledButton, PremiumSurface } from '@/components';

export default function NotFoundScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 20 }}>
      <PremiumSurface>
        <Text variant="displaySmall">404</Text>
        <Text variant="headlineSmall">Pantalla no encontrada</Text>
        <Text variant="bodyMedium">La ruta solicitada no existe en esta arquitectura expo-router.</Text>
        <FilledButton onPress={() => router.replace('/(tabs)')}>Volver al inicio</FilledButton>
      </PremiumSurface>
    </View>
  );
}
