import React from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { Button, Chip, Modal, Portal, Searchbar, SegmentedButtons, Switch, Text, TextInput, useTheme } from 'react-native-paper';
import { PremiumSurface } from './primitives';

export function SearchBarField(props: React.ComponentProps<typeof Searchbar>) {
  return <Searchbar style={styles.input} inputStyle={{ minHeight: 48 }} {...props} />;
}

export function InputField(props: React.ComponentProps<typeof TextInput>) {
  return <TextInput mode="outlined" style={styles.input} {...props} />;
}

export function FormSheet({ visible = true, title, children, cta = 'Guardar' }: React.PropsWithChildren<{ visible?: boolean; title: string; cta?: string }>) {
  const theme = useTheme();
  return (
    <Portal>
      <Modal visible={visible} dismissable={false} contentContainerStyle={[styles.sheet, { backgroundColor: (theme.colors as any).surfaceContainerLow }]}> 
        <ScrollView contentContainerStyle={{ gap: 16 }}>
          <Text variant="headlineSmall">{title}</Text>
          {children}
          <Button mode="contained" contentStyle={{ minHeight: 48 }}>{cta}</Button>
        </ScrollView>
      </Modal>
    </Portal>
  );
}

export function ModalHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  const theme = useTheme();
  return (
    <View style={{ gap: 4 }}>
      <Text variant="titleLarge">{title}</Text>
      {subtitle ? <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>{subtitle}</Text> : null}
    </View>
  );
}

export function FilterChips({ items }: { items: string[] }) {
  return (
    <View style={styles.chipsRow}>
      {items.map((item, index) => <Chip key={item} selected={index === 0}>{item}</Chip>)}
    </View>
  );
}

export function FinanceSegmentedControl() {
  return (
    <SegmentedButtons
      value="resumen"
      onValueChange={() => {}}
      buttons={[
        { value: 'resumen', label: 'Resumen' },
        { value: 'ingresos', label: 'Ingresos' },
        { value: 'movimientos', label: 'Movimientos' },
      ]}
    />
  );
}

export function SettingsSwitch({ label, value }: { label: string; value: boolean }) {
  return (
    <PremiumSurface>
      <View style={styles.switchRow}>
        <Text variant="titleMedium">{label}</Text>
        <Switch value={value} />
      </View>
    </PremiumSurface>
  );
}

const styles = StyleSheet.create({
  input: {
    borderRadius: 18,
  },
  sheet: {
    margin: 16,
    borderRadius: 28,
    padding: 20,
    maxHeight: '88%',
  },
  chipsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
