import React from 'react';
import { View } from 'react-native';
import { ActivityCard, AlertCard, HeroScoreCard, InsightCard, SelectableCard, StatCard, WeatherCard } from '../index';

export default {
  title: 'Datos/Cards',
};

export const Overview = {
  render: () => (
    <View style={{ gap: 16 }}>
      <HeroScoreCard title="Índice integral de finca" score={91} caption="Sincronizado hace 3 min" />
      <StatCard label="Producción semanal" value="2.480 kg" trend="+12%" />
      <InsightCard title="Recomendación IA" description="Priorizar corte en La Loma antes de la lluvia vespertina." footer="Operación" />
      <WeatherCard temperature="18 °C · neblina ligera" subtitle="Humedad y temperatura dentro de ventana ideal." moisture="74%" />
      <ActivityCard title="Recolección selectiva" subtitle="Lote La Loma · 12 personas" status="En curso" />
      <AlertCard title="Atención requerida" description="2 compras pendientes de conciliación visual." />
      <SelectableCard title="Registrar actividad" description="Acceso de alto contraste y feedback tonal." selected />
      <SelectableCard title="Registrar compra" description="Variante outline para acción secundaria." />
    </View>
  ),
};
