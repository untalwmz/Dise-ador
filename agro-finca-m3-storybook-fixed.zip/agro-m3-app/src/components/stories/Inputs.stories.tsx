import React from 'react';
import { View } from 'react-native';
import { Chip, Switch, Text } from 'react-native-paper';
import { FilterChips, InputField, SearchBarField } from '../index';

export default {
  title: 'Formularios/Inputs',
};

export const FormControls = {
  render: () => (
    <View style={{ gap: 16 }}>
      <SearchBarField placeholder="Buscar lote, variedad o labor" value="La Loma" onChangeText={() => {}} />
      <InputField label="Lote" value="La Loma" onChangeText={() => {}} />
      <InputField label="Labor" value="Recolección selectiva" onChangeText={() => {}} />
      <InputField label="Productos" value="Canastillas, guantes, etiquetas" onChangeText={() => {}} />
      <FilterChips items={['Cosecha', 'Fertilización', 'Beneficio']} />
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text variant="titleMedium">Sincronización offline prioritaria</Text>
        <Switch value />
      </View>
      <Chip icon="information-outline">Tamaños táctiles preparados para 48dp o más</Chip>
    </View>
  ),
};
