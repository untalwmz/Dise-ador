import React from 'react';
import { View } from 'react-native';
import { Text, useTheme } from 'react-native-paper';
import { PremiumSurface } from '../index';

function Swatch({ name, color, onColor }: { name: string; color: string; onColor: string }) {
  return (
    <View style={{ gap: 8 }}>
      <View style={{ height: 64, borderRadius: 20, backgroundColor: color, justifyContent: 'center', paddingHorizontal: 16 }}>
        <Text variant="titleMedium" style={{ color: onColor }}>{name}</Text>
      </View>
      <Text variant="bodySmall">{color}</Text>
    </View>
  );
}

export default {
  title: 'Foundation/Tokens M3',
};

export const MaterialYouPalette = {
  render: () => {
    const theme = useTheme();
    return (
      <View style={{ gap: 16 }}>
        <PremiumSurface>
          <Text variant="headlineSmall">Paleta agrícola Material You</Text>
          <Text variant="bodyMedium">Color seed, superficies y contenedores listos para claro y oscuro.</Text>
        </PremiumSurface>
        <Swatch name="Primary" color={theme.colors.primary} onColor={theme.colors.onPrimary} />
        <Swatch name="Primary Container" color={theme.colors.primaryContainer} onColor={theme.colors.onPrimaryContainer} />
        <Swatch name="Secondary Container" color={theme.colors.secondaryContainer} onColor={theme.colors.onSecondaryContainer} />
        <Swatch name="Tertiary Container" color={theme.colors.tertiaryContainer} onColor={theme.colors.onTertiaryContainer} />
        <Swatch name="Surface Container High" color={(theme.colors as any).surfaceContainerHigh} onColor={theme.colors.onSurface} />
        <Swatch name="Error Container" color={theme.colors.errorContainer} onColor={theme.colors.onErrorContainer} />
      </View>
    );
  },
};
