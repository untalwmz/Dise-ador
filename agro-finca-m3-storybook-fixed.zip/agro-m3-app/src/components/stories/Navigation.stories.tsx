import React from 'react';
import { View } from 'react-native';
import { AppBar, Chip, DetailListItem, DrawerMenuSheet, Section, SectionLabel, TabBar } from '../designKit';

export default {
  title: 'Navegación/App shell',
};

export const AppChrome = {
  render: () => (
    <View style={{ gap: 16 }}>
      <AppBar title="Inicio" subtitle="Control premium de la finca" />
      <Section label="Estados de navegación" action="Ver todo" />
      <DetailListItem title="Lote La Loma" description="4.8 ha · Castillo · En cosecha" right={<Chip compact>Activo</Chip>} />
      <SectionLabel>Bottom navigation</SectionLabel>
      <TabBar />
    </View>
  ),
};

export const DrawerPreview = {
  render: () => <DrawerMenuSheet visible onDismiss={() => {}} />,
};
