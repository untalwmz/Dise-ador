import React from 'react';
import { View } from 'react-native';
import { Chip, Text } from 'react-native-paper';
import { FormSheet, ModalHeader, QuickActionModalCard } from '../designKit';
import { InputField } from '../index';

export default {
  title: 'Overlays/Sheets y modales',
};

export const ActivitySheet = {
  render: () => (
    <View style={{ minHeight: 640 }}>
      <FormSheet title="Formulario de actividad" cta="Guardar actividad">
        <ModalHeader title="Actividad agrícola" subtitle="Secciones: lote, labor, productos y personal" />
        <InputField label="Lote" value="La Loma" onChangeText={() => {}} />
        <InputField label="Labor" value="Recolección selectiva" onChangeText={() => {}} />
        <InputField label="Personal" value="12 trabajadores" onChangeText={() => {}} />
        <Chip icon="clock-outline">Duración estimada 2 h</Chip>
        <Text variant="bodySmall">Componente listo para reconectar callbacks reales.</Text>
      </FormSheet>
    </View>
  ),
};

export const QuickActions = {
  render: () => <QuickActionModalCard />,
};
