import React from 'react';
import { View } from 'react-native';
import { FinanceBars, SegmentedTrend, Sparkline } from '../index';
import { SyncStatusChip } from '../designKit';

export default {
  title: 'Feedback/Estados y gráficos',
};

export const StatusCollection = {
  render: () => (
    <View style={{ gap: 16 }}>
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <SyncStatusChip status="online" />
        <SyncStatusChip status="pending" />
        <SyncStatusChip status="error" />
      </View>
      <SegmentedTrend items={[{ label: 'Balance', value: '€42.380' }, { label: 'Ingresos', value: '€12.400' }, { label: 'Gastos', value: '€7.920' }]} />
      <Sparkline label="Rendimiento semanal" values={[14, 16, 22, 20, 24, 28, 26]} />
      <FinanceBars />
    </View>
  ),
};
