import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { ExtendedFarmFab, FilledButton, OutlinedButton, TonalButton } from '../index';

export default {
  title: 'Acciones/Botones',
  args: {
    label: 'Guardar actividad',
    disabled: false,
  },
  argTypes: {
    label: { control: 'text' },
    disabled: { control: 'boolean' },
    onPress: { action: 'pressed' },
  },
};

export const Filled = {
  render: ({ label, disabled, onPress }: any) => <FilledButton disabled={disabled} onPress={onPress}>{label}</FilledButton>,
};

export const Tonal = {
  render: ({ label, disabled, onPress }: any) => <TonalButton disabled={disabled} onPress={onPress}>{label}</TonalButton>,
};

export const Outlined = {
  render: ({ label, disabled, onPress }: any) => <OutlinedButton disabled={disabled} onPress={onPress}>{label}</OutlinedButton>,
};

export const FloatingActions = {
  render: () => (
    <View style={{ gap: 24, minHeight: 160, justifyContent: 'center' }}>
      <Text variant="titleMedium">FAB y Extended FAB</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
        <ExtendedFarmFab icon="plus" label="Nueva labor" onPress={() => {}} />
      </View>
    </View>
  ),
};
