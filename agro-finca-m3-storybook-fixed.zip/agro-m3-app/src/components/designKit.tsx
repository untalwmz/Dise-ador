import React from 'react';
import { View } from 'react-native';
import { Appbar, Chip, IconButton, Searchbar, Text, useTheme } from 'react-native-paper';
import { quickActions } from '@/mocks/data';
import { ActivityCard, AlertCard, HeroScoreCard, InsightCard, SelectableCard, StatCard, WeatherCard } from './cards';
import { Sparkline } from './charts';
import { FormSheet, InputField, ModalHeader, SearchBarField } from './form';
import { DrawerMenu, Section } from './layout';
import { FilledButton, KpiBadge, OutlinedButton, PremiumSurface, StateListItem, TonalButton, TonalIconButton } from './primitives';

export function AppBar({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <Appbar.Header elevated>
      <Appbar.Action icon="menu" onPress={() => {}} />
      <Appbar.Content title={title} subtitle={subtitle} />
      <Appbar.Action icon="magnify" onPress={() => {}} />
    </Appbar.Header>
  );
}

export function TabBar() {
  const theme = useTheme();
  return (
    <PremiumSurface style={{ flexDirection: 'row', justifyContent: 'space-between', backgroundColor: (theme.colors as any).surfaceContainerLow }}>
      {['Inicio', 'Lotes', 'Acción', 'Finanzas'].map((label, index) => (
        <View key={label} style={{ alignItems: 'center', gap: 4, minWidth: 64 }}>
          <IconButton icon={index === 2 ? 'lightning-bolt-circle' : 'circle-medium'} />
          <Text variant="labelMedium">{label}</Text>
        </View>
      ))}
    </PremiumSurface>
  );
}

export function DrawerMenuSheet(props: React.ComponentProps<typeof DrawerMenu>) {
  return <DrawerMenu {...props} />;
}

export function DetailListItem(props: React.ComponentProps<typeof StateListItem>) {
  return <StateListItem {...props} />;
}

export function SectionLabel({ children }: React.PropsWithChildren) {
  return <Text variant="labelLarge">{children}</Text>;
}

export function PrimaryButton(props: React.ComponentProps<typeof FilledButton>) {
  return <FilledButton {...props} />;
}

export function SecondaryButton(props: React.ComponentProps<typeof TonalButton>) {
  return <TonalButton {...props} />;
}

export function Input(props: React.ComponentProps<typeof InputField>) {
  return <InputField {...props} />;
}

export function SearchBarComponent(props: React.ComponentProps<typeof Searchbar>) {
  return <SearchBarField {...props} />;
}

export function QuickActionModalCard() {
  return (
    <FormSheet title="Quick actions" cta="Ejecutar">
      {quickActions.map((action, index) => (
        <SelectableCard key={action} title={action} description="Acción optimizada para operación rápida" selected={index === 0} />
      ))}
    </FormSheet>
  );
}

export function SyncStatusChip({ status = 'online' }: { status?: 'online' | 'pending' | 'error' }) {
  const map = {
    online: { icon: 'check-circle-outline', label: 'Online' },
    pending: { icon: 'progress-clock', label: 'Pendiente' },
    error: { icon: 'alert-circle-outline', label: 'Error' },
  } as const;
  const current = map[status];
  return <Chip icon={current.icon}>{current.label}</Chip>;
}

export {
  PremiumSurface as Card,
  StatCard,
  HeroScoreCard,
  InsightCard,
  AlertCard,
  ActivityCard,
  WeatherCard,
  SelectableCard,
  Section,
  Chip,
  TonalIconButton as IconButton,
  Sparkline,
  FormSheet,
  ModalHeader,
  KpiBadge,
  OutlinedButton,
};
