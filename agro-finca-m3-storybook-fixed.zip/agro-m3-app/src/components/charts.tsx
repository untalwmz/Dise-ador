import React from 'react';
import { View, StyleSheet } from 'react-native';
import Svg, { Path, Rect } from 'react-native-svg';
import { Text, useTheme } from 'react-native-paper';
import { PremiumSurface } from './primitives';

export function Sparkline({ values, label }: { values: number[]; label: string }) {
  const theme = useTheme();
  const max = Math.max(...values);
  const min = Math.min(...values);
  const points = values.map((value, index) => {
    const x = (index / (values.length - 1)) * 180;
    const y = 44 - ((value - min) / (max - min || 1)) * 36;
    return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
  }).join(' ');

  return (
    <PremiumSurface>
      <Text variant="titleMedium">{label}</Text>
      <Svg width="180" height="48" viewBox="0 0 180 48">
        <Path d={points} stroke={theme.colors.primary} strokeWidth={3} fill="none" strokeLinecap="round" />
      </Svg>
    </PremiumSurface>
  );
}

export function FinanceBars() {
  const theme = useTheme();
  const bars = [72, 48, 90, 64, 56, 84];
  return (
    <PremiumSurface>
      <Text variant="titleMedium">Flujo de caja 6 semanas</Text>
      <Svg width="100%" height="120" viewBox="0 0 260 120">
        {bars.map((bar, index) => (
          <Rect
            key={index}
            x={index * 42 + 8}
            y={110 - bar}
            width="24"
            height={bar}
            rx="12"
            fill={index % 2 === 0 ? theme.colors.primary : theme.colors.tertiary}
          />
        ))}
      </Svg>
    </PremiumSurface>
  );
}

export function SegmentedTrend({ items }: { items: { label: string; value: string }[] }) {
  const theme = useTheme();
  return (
    <View style={styles.row}>
      {items.map((item) => (
        <View key={item.label} style={[styles.segment, { backgroundColor: (theme.colors as any).surfaceContainerHigh }]}> 
          <Text variant="labelMedium" style={{ color: theme.colors.onSurfaceVariant }}>{item.label}</Text>
          <Text variant="titleMedium">{item.value}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  segment: {
    flex: 1,
    borderRadius: 20,
    padding: 14,
    gap: 6,
  },
});
