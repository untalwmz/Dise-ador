import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Card, Chip, ProgressBar, Text, useTheme } from 'react-native-paper';
import { PremiumSurface } from './primitives';

export function StatCard({ label, value, trend }: { label: string; value: string; trend: string }) {
  const theme = useTheme();
  return (
    <Card mode="contained" style={[styles.card, { backgroundColor: (theme.colors as any).surfaceContainerLow }]}> 
      <Card.Content style={styles.cardContent}>
        <Text variant="labelMedium" style={{ color: theme.colors.onSurfaceVariant }}>{label}</Text>
        <Text variant="headlineSmall">{value}</Text>
        <Chip compact icon="trending-up" style={{ alignSelf: 'flex-start' }}>{trend}</Chip>
      </Card.Content>
    </Card>
  );
}

export function HeroScoreCard({ title, score, caption }: { title: string; score: number; caption: string }) {
  const theme = useTheme();
  return (
    <Card mode="elevated" style={[styles.hero, { backgroundColor: theme.colors.primaryContainer }]}> 
      <Card.Content style={styles.heroContent}>
        <Text variant="titleMedium" style={{ color: theme.colors.onPrimaryContainer }}>{title}</Text>
        <Text variant="displaySmall" style={{ color: theme.colors.onPrimaryContainer }}>{score}</Text>
        <Text variant="bodyMedium" style={{ color: theme.colors.onPrimaryContainer }}>{caption}</Text>
        <ProgressBar progress={score / 100} color={theme.colors.primary} style={styles.progress} />
      </Card.Content>
    </Card>
  );
}

export function InsightCard({ title, description, footer }: { title: string; description: string; footer: string }) {
  const theme = useTheme();
  return (
    <PremiumSurface style={{ backgroundColor: (theme.colors as any).surfaceContainer }}>
      <Text variant="titleMedium">{title}</Text>
      <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>{description}</Text>
      <Chip icon="lightbulb-on-outline" compact>{footer}</Chip>
    </PremiumSurface>
  );
}

export function AlertCard({ title, description }: { title: string; description: string }) {
  const theme = useTheme();
  return (
    <Card mode="contained" style={{ backgroundColor: theme.colors.errorContainer, borderRadius: 24 }}>
      <Card.Content style={styles.cardContent}>
        <Text variant="titleMedium" style={{ color: theme.colors.onErrorContainer }}>{title}</Text>
        <Text variant="bodyMedium" style={{ color: theme.colors.onErrorContainer }}>{description}</Text>
      </Card.Content>
    </Card>
  );
}

export function ActivityCard({ title, subtitle, status }: { title: string; subtitle: string; status: string }) {
  const theme = useTheme();
  return (
    <PremiumSurface>
      <View style={styles.row}>
        <View style={{ flex: 1, gap: 4 }}>
          <Text variant="titleMedium">{title}</Text>
          <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>{subtitle}</Text>
        </View>
        <Chip compact>{status}</Chip>
      </View>
    </PremiumSurface>
  );
}

export function WeatherCard({ temperature, subtitle, moisture }: { temperature: string; subtitle: string; moisture: string }) {
  const theme = useTheme();
  return (
    <PremiumSurface style={{ backgroundColor: theme.colors.tertiaryContainer }}>
      <Text variant="titleMedium" style={{ color: theme.colors.onTertiaryContainer }}>Microclima</Text>
      <Text variant="headlineMedium" style={{ color: theme.colors.onTertiaryContainer }}>{temperature}</Text>
      <Text variant="bodyMedium" style={{ color: theme.colors.onTertiaryContainer }}>{subtitle}</Text>
      <Chip compact icon="water-percent" style={{ alignSelf: 'flex-start' }}>{moisture}</Chip>
    </PremiumSurface>
  );
}

export function SelectableCard({ title, description, selected }: { title: string; description: string; selected?: boolean }) {
  const theme = useTheme();
  return (
    <Card mode={selected ? 'contained' : 'outlined'} style={{ borderRadius: 24, backgroundColor: selected ? theme.colors.secondaryContainer : theme.colors.surface }}>
      <Card.Content style={styles.cardContent}>
        <Text variant="titleMedium">{title}</Text>
        <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>{description}</Text>
      </Card.Content>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 180,
    borderRadius: 24,
  },
  cardContent: {
    gap: 8,
  },
  hero: {
    borderRadius: 28,
  },
  heroContent: {
    gap: 10,
    paddingVertical: 4,
  },
  progress: {
    height: 8,
    borderRadius: 999,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
});
