import React from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Divider, Drawer, IconButton, Modal, Portal, Text, useTheme } from 'react-native-paper';
import { FilledButton, TonalButton } from './primitives';

export function ScreenTemplate({
  title,
  subtitle,
  children,
  actionLabel,
  onAction,
}: React.PropsWithChildren<{ title: string; subtitle?: string; actionLabel?: string; onAction?: () => void }>) {
  const theme = useTheme();
  const [drawerVisible, setDrawerVisible] = React.useState(false);
  return (
    <View style={[styles.page, { backgroundColor: theme.colors.background }]}> 
      <View style={styles.header}>
        <IconButton icon="menu" mode="contained-tonal" onPress={() => setDrawerVisible(true)} />
        <View style={{ flex: 1 }}>
          <Text variant="headlineSmall">{title}</Text>
          {subtitle ? <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>{subtitle}</Text> : null}
        </View>
        {actionLabel ? <FilledButton onPress={onAction}>{actionLabel}</FilledButton> : null}
      </View>
      <ScrollView contentContainerStyle={styles.content}>{children}</ScrollView>
      <DrawerMenu visible={drawerVisible} onDismiss={() => setDrawerVisible(false)} />
    </View>
  );
}

export function DrawerMenu({ visible, onDismiss }: { visible: boolean; onDismiss: () => void }) {
  const theme = useTheme();
  const item = (label: string, icon: string, href: any) => (
    <Drawer.Item
      label={label}
      icon={icon}
      onPress={() => {
        onDismiss();
        router.push(href);
      }}
    />
  );
  return (
    <Portal>
      <Modal visible={visible} onDismiss={onDismiss} contentContainerStyle={[styles.drawer, { backgroundColor: (theme.colors as any).surfaceContainerLow }]}> 
        <Text variant="headlineSmall">Menú agrícola</Text>
        <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>Navegación secundaria y herramientas</Text>
        <Divider style={{ marginVertical: 12 }} />
        {item('Cosecha', 'coffee', '/(tabs)/cosecha')}
        {item('Calendario', 'calendar-month', '/(tabs)/calendario')}
        {item('Trabajadores', 'account-group', '/(tabs)/trabajadores')}
        {item('Reportes', 'chart-box-outline', '/reportes')}
        {item('Ajustes', 'tune-variant', '/(tabs)/ajustes')}
        {item('Ayuda', 'lifebuoy', '/ayuda')}
        {item('Logs', 'text-box-search-outline', '/logs')}
        <View style={styles.drawerActions}>
          <TonalButton icon="lightning-bolt" onPress={() => router.push('/quick-action-modal')}>Acción rápida</TonalButton>
        </View>
      </Modal>
    </Portal>
  );
}

export function Section({ label, action }: { label: string; action?: string }) {
  const theme = useTheme();
  return (
    <View style={styles.sectionHeader}>
      <Text variant="titleLarge">{label}</Text>
      {action ? <Text variant="labelLarge" style={{ color: theme.colors.primary }}>{action}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 16,
    paddingTop: 18,
    paddingBottom: 10,
  },
  content: {
    padding: 16,
    gap: 16,
    paddingBottom: 120,
  },
  drawer: {
    margin: 16,
    padding: 18,
    borderRadius: 28,
  },
  drawerActions: {
    marginTop: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
