import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Button, FAB, IconButton, Surface, Text, TouchableRipple, useTheme } from 'react-native-paper';

export function PremiumSurface({ children, style }: React.PropsWithChildren<{ style?: any }>) {
  const theme = useTheme();
  return (
    <Surface
      style={[
        styles.surface,
        {
          backgroundColor: theme.colors.elevation.level1,
          borderRadius: theme.roundness + 6,
          borderColor: theme.colors.outlineVariant,
        },
        style,
      ]}
      elevation={2}
    >
      {children}
    </Surface>
  );
}

export function FilledButton(props: React.ComponentProps<typeof Button>) {
  return <Button mode="contained" contentStyle={styles.buttonContent} style={styles.button} {...props} />;
}

export function TonalButton(props: React.ComponentProps<typeof Button>) {
  return <Button mode="contained-tonal" contentStyle={styles.buttonContent} style={styles.button} {...props} />;
}

export function OutlinedButton(props: React.ComponentProps<typeof Button>) {
  return <Button mode="outlined" contentStyle={styles.buttonContent} style={styles.button} {...props} />;
}

export function FarmFab(props: React.ComponentProps<typeof FAB>) {
  return <FAB variant="primary" size="medium" style={styles.fab} {...props} />;
}

export function ExtendedFarmFab(props: React.ComponentProps<typeof FAB>) {
  return <FAB variant="tertiary" mode="flat" style={styles.extendedFab} {...props} />;
}

export function StateListItem({
  title,
  description,
  right,
  onPress,
}: {
  title: string;
  description?: string;
  right?: React.ReactNode;
  onPress?: () => void;
}) {
  const theme = useTheme();
  return (
    <TouchableRipple
      onPress={onPress}
      borderless={false}
      style={[styles.listItem, { borderRadius: theme.roundness + 2 }]}
    >
      <View style={styles.listContent}>
        <View style={{ flex: 1 }}>
          <Text variant="titleMedium">{title}</Text>
          {description ? <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>{description}</Text> : null}
        </View>
        {right}
      </View>
    </TouchableRipple>
  );
}

export function KpiBadge({ label, value }: { label: string; value: string }) {
  const theme = useTheme();
  return (
    <View style={[styles.badge, { backgroundColor: theme.colors.secondaryContainer }]}> 
      <Text variant="labelMedium" style={{ color: theme.colors.onSecondaryContainer }}>{label}</Text>
      <Text variant="titleMedium" style={{ color: theme.colors.onSecondaryContainer }}>{value}</Text>
    </View>
  );
}

export function TonalIconButton(props: React.ComponentProps<typeof IconButton>) {
  return <IconButton mode="contained-tonal" size={20} {...props} />;
}

const styles = StyleSheet.create({
  surface: {
    padding: 16,
    borderWidth: 1,
    gap: 12,
  },
  button: {
    borderRadius: 999,
  },
  buttonContent: {
    minHeight: 48,
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 28,
  },
  extendedFab: {
    borderRadius: 18,
  },
  listItem: {
    overflow: 'hidden',
  },
  listContent: {
    minHeight: 56,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
  },
  badge: {
    minWidth: 92,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 16,
    gap: 4,
  },
});
