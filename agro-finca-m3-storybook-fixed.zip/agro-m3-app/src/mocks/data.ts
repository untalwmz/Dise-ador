export const dashboardStats = [
  { label: 'Producción semanal', value: '2.480 kg', trend: '+12%', tone: 'primary' },
  { label: 'Lotes activos', value: '18', trend: '+2', tone: 'secondary' },
  { label: 'Costo por kg', value: '€1,84', trend: '-4%', tone: 'tertiary' },
  { label: 'Tareas críticas', value: '5', trend: 'Hoy', tone: 'error' },
];

export const heroKpis = {
  health: 91,
  climate: '18 °C · neblina ligera',
  moisture: '74%',
  sync: 'Sincronizado hace 3 min',
};

export const lots = [
  { id: 'l1', name: 'Lote La Loma', hectares: 4.8, variety: 'Castillo', progress: 82, status: 'En cosecha', elevation: '1.620 msnm' },
  { id: 'l2', name: 'Lote El Mirador', hectares: 3.1, variety: 'Caturra', progress: 54, status: 'Fertilización', elevation: '1.540 msnm' },
  { id: 'l3', name: 'Lote Quebrada Alta', hectares: 5.2, variety: 'Colombia', progress: 68, status: 'Beneficio', elevation: '1.700 msnm' },
];

export const workers = [
  { id: 'w1', name: 'María Gómez', role: 'Capataz', performance: 94, shift: '06:00–15:00', status: 'Disponible' },
  { id: 'w2', name: 'Jorge Ramírez', role: 'Recolector', performance: 88, shift: '07:00–16:00', status: 'En lote' },
  { id: 'w3', name: 'Ana Lucía Pérez', role: 'Beneficio', performance: 91, shift: '08:00–17:00', status: 'En planta' },
];

export const financeSummary = {
  balance: '€42.380',
  income: '€12.400',
  expenses: '€7.920',
  margin: '36%',
};

export const financeSegments = ['Resumen', 'Ingresos', 'Movimientos'];

export const financeMovements = [
  { id: 'm1', title: 'Venta pergamino seco', amount: '+€4.900', category: 'Ingreso', date: 'Hoy · 09:10' },
  { id: 'm2', title: 'Compra fertilizante 18-18-18', amount: '-€1.320', category: 'Gasto', date: 'Ayer · 17:42' },
  { id: 'm3', title: 'Pago cuadrilla temporal', amount: '-€860', category: 'Personal', date: 'Ayer · 13:15' },
];

export const harvestActivities = [
  { title: 'Recolección selectiva', subtitle: 'Lote La Loma · 12 personas', status: 'En curso' },
  { title: 'Lavado de canales', subtitle: 'Beneficio central', status: 'Programado' },
  { title: 'Aplicación biológica', subtitle: 'Lote El Mirador', status: 'Pendiente' },
];

export const reports = [
  { title: 'Reporte semanal de cosecha', description: 'KPIs de producción, rendimiento y merma por lote.' },
  { title: 'Reporte de beneficio', description: 'Control de humedad, fermentación y trazabilidad.' },
  { title: 'Análisis financiero mensual', description: 'Ingresos, compras, flujo de caja y desviaciones.' },
];

export const quickActions = [
  'Registrar actividad',
  'Nuevo movimiento',
  'Entrada a beneficio',
  'Asignar trabajador',
  'Crear lote',
  'Sincronizar ahora',
];
