import { MD3DarkTheme, MD3LightTheme, type MD3Theme } from 'react-native-paper';
import { buildMaterialYouScheme } from './materialYou';

export const seedColor = '#3f6b2a';

export const shape = {
  none: 0,
  xs: 8,
  sm: 12,
  md: 16,
  lg: 22,
  xl: 28,
  pill: 999,
};

export const spacing = {
  xxs: 4,
  xs: 8,
  sm: 12,
  md: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
};

export const motion = {
  durations: {
    short1: 100,
    short2: 200,
    medium1: 250,
    medium2: 300,
    long1: 400,
    long2: 500,
  },
  easing: {
    standard: 'cubic-bezier(0.2, 0, 0, 1)',
    emphasized: 'cubic-bezier(0.2, 0, 0, 1)',
    decelerate: 'cubic-bezier(0, 0, 0, 1)',
    accelerate: 'cubic-bezier(0.3, 0, 1, 1)',
  },
};

const defaultFont = { fontFamily: 'System', fontWeight: '400' as const, letterSpacing: 0 };

const typeScale = {
  default: defaultFont,
  displayLarge: { fontFamily: 'System', fontWeight: '700' as const, fontSize: 57, lineHeight: 64, letterSpacing: 0 },
  displayMedium: { fontFamily: 'System', fontWeight: '700' as const, fontSize: 45, lineHeight: 52, letterSpacing: 0 },
  displaySmall: { fontFamily: 'System', fontWeight: '700' as const, fontSize: 36, lineHeight: 44, letterSpacing: 0 },
  headlineLarge: { fontFamily: 'System', fontWeight: '700' as const, fontSize: 32, lineHeight: 40, letterSpacing: 0 },
  headlineMedium: { fontFamily: 'System', fontWeight: '700' as const, fontSize: 28, lineHeight: 36, letterSpacing: 0 },
  headlineSmall: { fontFamily: 'System', fontWeight: '700' as const, fontSize: 24, lineHeight: 32, letterSpacing: 0 },
  titleLarge: { fontFamily: 'System', fontWeight: '700' as const, fontSize: 22, lineHeight: 28, letterSpacing: 0 },
  titleMedium: { fontFamily: 'System', fontWeight: '600' as const, fontSize: 16, lineHeight: 24, letterSpacing: 0.15 },
  titleSmall: { fontFamily: 'System', fontWeight: '600' as const, fontSize: 14, lineHeight: 20, letterSpacing: 0.1 },
  bodyLarge: { fontFamily: 'System', fontWeight: '400' as const, fontSize: 16, lineHeight: 24, letterSpacing: 0.15 },
  bodyMedium: { fontFamily: 'System', fontWeight: '400' as const, fontSize: 14, lineHeight: 20, letterSpacing: 0.25 },
  bodySmall: { fontFamily: 'System', fontWeight: '400' as const, fontSize: 12, lineHeight: 16, letterSpacing: 0.4 },
  labelLarge: { fontFamily: 'System', fontWeight: '600' as const, fontSize: 14, lineHeight: 20, letterSpacing: 0.1 },
  labelMedium: { fontFamily: 'System', fontWeight: '600' as const, fontSize: 12, lineHeight: 16, letterSpacing: 0.5 },
  labelSmall: { fontFamily: 'System', fontWeight: '600' as const, fontSize: 11, lineHeight: 16, letterSpacing: 0.5 },
};

export const getAppTheme = (dark: boolean): MD3Theme & {
  custom: {
    seedColor: string;
    spacing: typeof spacing;
    shape: typeof shape;
    motion: typeof motion;
  };
} => {
  const scheme = buildMaterialYouScheme(seedColor, dark);
  const base = dark ? MD3DarkTheme : MD3LightTheme;

  return {
    ...base,
    dark,
    version: 3,
    roundness: shape.md,
    colors: {
      ...base.colors,
      ...(scheme as any),
      elevation: {
        level0: scheme.surface,
        level1: scheme.surfaceContainerLow,
        level2: scheme.surfaceContainer,
        level3: scheme.surfaceContainerHigh,
        level4: scheme.surfaceContainerHighest,
        level5: scheme.surfaceContainerHighest,
      },
    },
    fonts: typeScale as any,
    custom: {
      seedColor,
      spacing,
      shape,
      motion,
    },
  };
};
