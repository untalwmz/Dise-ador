export type ToneRoles = {
  primary: string;
  onPrimary: string;
  primaryContainer: string;
  onPrimaryContainer: string;
  secondary: string;
  onSecondary: string;
  secondaryContainer: string;
  onSecondaryContainer: string;
  tertiary: string;
  onTertiary: string;
  tertiaryContainer: string;
  onTertiaryContainer: string;
  error: string;
  onError: string;
  errorContainer: string;
  onErrorContainer: string;
  background: string;
  onBackground: string;
  surface: string;
  onSurface: string;
  surfaceVariant: string;
  onSurfaceVariant: string;
  outline: string;
  outlineVariant: string;
  shadow: string;
  scrim: string;
  inverseSurface: string;
  inverseOnSurface: string;
  inversePrimary: string;
  surfaceTint: string;
  surfaceContainerLowest: string;
  surfaceContainerLow: string;
  surfaceContainer: string;
  surfaceContainerHigh: string;
  surfaceContainerHighest: string;
};

const clamp = (value: number, min = 0, max = 255) => Math.max(min, Math.min(max, value));

const hexToRgb = (hex: string) => {
  const normalized = hex.replace('#', '');
  const bigint = parseInt(normalized.length === 3
    ? normalized.split('').map((c) => c + c).join('')
    : normalized, 16);
  return {
    r: (bigint >> 16) & 255,
    g: (bigint >> 8) & 255,
    b: bigint & 255,
  };
};

const rgbToHex = (r: number, g: number, b: number) =>
  `#${[r, g, b].map((v) => clamp(v).toString(16).padStart(2, '0')).join('')}`;

const mix = (hexA: string, hexB: string, amount: number) => {
  const a = hexToRgb(hexA);
  const b = hexToRgb(hexB);
  return rgbToHex(
    Math.round(a.r + (b.r - a.r) * amount),
    Math.round(a.g + (b.g - a.g) * amount),
    Math.round(a.b + (b.b - a.b) * amount),
  );
};

const shift = (hex: string, amount: number) => mix(hex, amount > 0 ? '#ffffff' : '#000000', Math.abs(amount));

export const buildMaterialYouScheme = (seed: string, dark: boolean): ToneRoles => {
  const secondarySeed = mix(seed, '#7b5e3b', 0.42);
  const tertiarySeed = mix(seed, '#9b6b3f', 0.68);

  if (dark) {
    return {
      primary: shift(seed, 0.34),
      onPrimary: '#17361d',
      primaryContainer: shift(seed, -0.42),
      onPrimaryContainer: shift(seed, 0.72),
      secondary: shift(secondarySeed, 0.42),
      onSecondary: '#2f2418',
      secondaryContainer: shift(secondarySeed, -0.38),
      onSecondaryContainer: shift(secondarySeed, 0.7),
      tertiary: shift(tertiarySeed, 0.35),
      onTertiary: '#3b2411',
      tertiaryContainer: shift(tertiarySeed, -0.36),
      onTertiaryContainer: shift(tertiarySeed, 0.72),
      error: '#ffb4ab',
      onError: '#690005',
      errorContainer: '#93000a',
      onErrorContainer: '#ffdad6',
      background: '#101510',
      onBackground: '#e0e4da',
      surface: '#101510',
      onSurface: '#e0e4da',
      surfaceVariant: '#43483f',
      onSurfaceVariant: '#c3c8bc',
      outline: '#8d9288',
      outlineVariant: '#43483f',
      shadow: '#000000',
      scrim: '#000000',
      inverseSurface: '#e0e4da',
      inverseOnSurface: '#2d322d',
      inversePrimary: shift(seed, -0.25),
      surfaceTint: shift(seed, 0.34),
      surfaceContainerLowest: '#0b0f0b',
      surfaceContainerLow: '#181d18',
      surfaceContainer: '#1c211c',
      surfaceContainerHigh: '#272b26',
      surfaceContainerHighest: '#313630',
    };
  }

  return {
    primary: shift(seed, -0.14),
    onPrimary: '#ffffff',
    primaryContainer: shift(seed, 0.78),
    onPrimaryContainer: shift(seed, -0.72),
    secondary: shift(secondarySeed, -0.12),
    onSecondary: '#ffffff',
    secondaryContainer: shift(secondarySeed, 0.8),
    onSecondaryContainer: shift(secondarySeed, -0.68),
    tertiary: shift(tertiarySeed, -0.08),
    onTertiary: '#ffffff',
    tertiaryContainer: shift(tertiarySeed, 0.82),
    onTertiaryContainer: shift(tertiarySeed, -0.7),
    error: '#ba1a1a',
    onError: '#ffffff',
    errorContainer: '#ffdad6',
    onErrorContainer: '#410002',
    background: '#f8fbf2',
    onBackground: '#191d18',
    surface: '#f8fbf2',
    onSurface: '#191d18',
    surfaceVariant: '#dfe5d7',
    onSurfaceVariant: '#43483f',
    outline: '#73796e',
    outlineVariant: '#c3c8bc',
    shadow: '#000000',
    scrim: '#000000',
    inverseSurface: '#2d322d',
    inverseOnSurface: '#eff2e8',
    inversePrimary: shift(seed, 0.45),
    surfaceTint: shift(seed, -0.14),
    surfaceContainerLowest: '#ffffff',
    surfaceContainerLow: '#f2f5ec',
    surfaceContainer: '#ecefe6',
    surfaceContainerHigh: '#e6e9e0',
    surfaceContainerHighest: '#e0e4da',
  };
};
