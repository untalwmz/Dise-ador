import React from 'react';
import { useColorScheme } from 'react-native';
import { PaperProvider } from 'react-native-paper';
import { StatusBar } from 'expo-status-bar';
import { getAppTheme } from './tokens';

export function AppThemeProvider({ children }: React.PropsWithChildren) {
  const system = useColorScheme();
  const dark = system === 'dark';
  const theme = React.useMemo(() => getAppTheme(dark), [dark]);

  return (
    <PaperProvider theme={theme}>
      <StatusBar style={dark ? 'light' : 'dark'} />
      {children}
    </PaperProvider>
  );
}
