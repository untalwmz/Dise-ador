export const percentageLabel = (value: number) => `${value}%`;
export const hectaresLabel = (value: number) => `${value.toFixed(1)} ha`;
