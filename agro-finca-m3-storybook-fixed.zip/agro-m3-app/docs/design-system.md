# Mini Design System · Agro Finca M3

## 1. Foundation

### Color
- Seed: `#3f6b2a`
- Primario: identidad finca / acciones principales
- Secundario: apoyo operativo / chips / filtros
- Terciario: clima, beneficio, analítica cálida
- Surface containers: jerarquía visual por elevación M3
- Error: incidentes, conflicto offline, validación

### Tipografía
Se usa la escala M3 completa en `src/theme/tokens.ts`:
- Display
- Headline
- Title
- Body
- Label

### Shape
- xs 8
- sm 12
- md 16
- lg 22
- xl 28
- pill 999

### Motion
Tokens incluidos para short / medium / long duration y easing estándar M3.

## 2. Mapping de componentes existentes a equivalentes M3

| Anterior | Equivalente entregado |
|---|---|
| AppBar | `AppBar` / `ScreenTemplate` |
| TabBar | tabs expo-router + `TabBar` demo |
| DrawerMenu | `DrawerMenu` / `DrawerMenuSheet` |
| Card | `Card` (`PremiumSurface`) |
| StatCard | `StatCard` |
| HeroScoreCard | `HeroScoreCard` |
| InsightCard | `InsightCard` |
| AlertCard | `AlertCard` |
| ActivityCard | `ActivityCard` |
| WeatherCard | `WeatherCard` |
| SelectableCard | `SelectableCard` |
| DetailListItem | `DetailListItem` (`StateListItem`) |
| Section / SectionLabel | `Section`, `SectionLabel` |
| Chip | `Chip` de react-native-paper |
| PrimaryButton | `PrimaryButton` (`FilledButton`) |
| SecondaryButton | `SecondaryButton` (`TonalButton`) |
| IconButton | `IconButton` tonal |
| Input | `Input` (`InputField`) |
| SearchBar | `SearchBarComponent` |
| FormSheet | `FormSheet` |
| ModalHeader | `ModalHeader` |
| QuickActionModal | `QuickActionModalCard` |
| Sparkline | `Sparkline` |
| SyncStatusChip | `SyncStatusChip` |

## 3. Props sugeridas para reconexión

### Botones
- `onPress?: () => void`
- `disabled?: boolean`
- `loading?: boolean`
- `icon?: string`

### Cards de datos
- `title: string`
- `description?: string`
- `value?: string`
- `status?: string`
- `onPress?: () => void`

### Inputs
- Mantienen la firma de `react-native-paper` (`value`, `onChangeText`, `label`, `error`, `disabled`)

### List items
- `title: string`
- `description?: string`
- `right?: ReactNode`
- `onPress?: () => void`

## 4. Estados visuales requeridos

- Filled, tonal, outlined
- Surface elevation levels 0–5
- State layer para pressed / hover / focus / disabled mediante Paper MD3
- Claro/oscuro automático vía `useColorScheme`

## 5. Storybook incluido

Se añadió Storybook on-device con configuración real para Expo Router:

- Carpeta `.rnstorybook/` con `main.ts`, `preview.tsx`, `index.tsx` y `storybook.requires.ts`
- Ruta `app/storybook.tsx` para abrir el catálogo desde la propia app
- Stories base para botones, cards, inputs, navegación, overlays, estados, gráficos y tokens
- Addons on-device para controls, actions, notes y backgrounds

## 6. Siguientes pasos recomendados

1. Conectar stores reales de lotes, finanzas y personal
2. Sustituir mock charts por datos reales
3. Añadir más stories por pantalla y estados edge-case
4. Incorporar motion avanzada con Reanimated usando los tokens ya definidos
