import React from 'react';
import { View } from 'react-native';
import { withBackgrounds } from '@storybook/addon-ondevice-backgrounds';
import type { Preview } from '@storybook/react-native';
import { Platform } from 'react-native';
import { PaperProvider } from 'react-native-paper';
import { getAppTheme } from '../src/theme';

if (Platform.OS === 'web') {
  // @ts-ignore
  global.ProgressTransitionRegister = {};
  // @ts-ignore
  global.UpdatePropsManager = {};
}

const lightTheme = getAppTheme(false);
const darkTheme = getAppTheme(true);

const preview: Preview = {
  decorators: [
    withBackgrounds,
    (Story) => (
      <PaperProvider theme={lightTheme}>
        <View style={{ flex: 1, padding: 16, backgroundColor: lightTheme.colors.background }}>
          <Story />
        </View>
      </PaperProvider>
    ),
  ],
  parameters: {
    backgrounds: {
      default: 'finca-light',
      values: [
        { name: 'finca-light', value: lightTheme.colors.background },
        { name: 'surface-high', value: (lightTheme.colors as any).surfaceContainerHigh },
        { name: 'finca-dark', value: darkTheme.colors.background },
      ],
    },
    actions: { argTypesRegex: '^on[A-Z].*' },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/,
      },
    },
  },
};

export default preview;
