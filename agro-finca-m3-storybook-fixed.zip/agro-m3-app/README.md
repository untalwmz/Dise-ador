# Agro Finca M3

Rediseño visual completo para una app móvil de gestión agrícola construida sobre **Expo SDK 54 + React Native 0.81 + TypeScript + expo-router**.

## Qué incluye

- Tema centralizado Material Design 3 / Material You con color semilla agrícola `#3f6b2a`
- Soporte claro/oscuro con tokens, superficies, contenedores y roles `on-*`
- Navegación principal por tabs y navegación secundaria vía drawer modal
- Pantallas principales, secundarias, auth, estados, detalle y modales
- Kit base de componentes M3 documentado y listo para reconectar a la lógica existente
- Storybook real on-device para revisar componentes y variantes en aislamiento
- Mock data para maquetación sin Supabase ni lógica de negocio

## Estructura

- `app/`: rutas expo-router
- `src/theme/`: theme provider, tokens, generador Material You
- `src/components/`: design kit premium, bloques reutilizables y stories
- `src/mocks/`: datos de ejemplo
- `docs/design-system.md`: mini documentación del sistema de diseño

## Integración

1. Instala dependencias con `npm install --legacy-peer-deps`
2. Inicia la app con `npm run start`
3. Genera las stories si añades nuevas con `npm run storybook:generate`
4. Abre Storybook navegando a la ruta `/storybook` dentro de la app en desarrollo
5. Reemplaza datos mock por tus hooks y stores reales
6. Mantén el consumo de color, tipografía y spacing a través del tema, no con valores sueltos

## Decisiones de diseño

- **Seed color**: verde café orgánico con secundarios tierra y terciarios cálidos
- **Superficies**: elevación basada en `surfaceTint` y niveles M3
- **Controles**: tamaños táctiles >= 48dp
- **Accesibilidad**: composición pensada para contraste AA y texto escalable
- **Motion**: tokens preparados en `src/theme/tokens.ts` para transiciones M3

## Mapa rápido de pantallas

- Tabs: Inicio, Lotes, Acción rápida, Finanzas
- Drawer: Cosecha, Calendario, Personal, Reportes, Ajustes, Ayuda, Logs
- Detalle: lote, trabajador
- Modales: actividad, beneficio, movimiento, lote, trabajador, quick action
- Sistema: login, reset-password, config-error, loading, 404
